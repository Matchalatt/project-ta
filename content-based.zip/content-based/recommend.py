# File: recommend.py
import sys
import pandas as pd
import pymysql
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def get_recommendations(product_id, num_recommendations=5):
    # --- 1. Konfigurasi & Koneksi Database ---
    # Sesuaikan dengan konfigurasi database .env Laravel Anda
    db_config = {
        'host': '127.0.0.1',
        'user': 'root', # Ganti dengan username db Anda
        'password': '', # Ganti dengan password db Anda
        'db': 'snackjuara', # Ganti dengan nama db Anda
        'charset': 'utf8mb4'
    }

    df = pd.DataFrame() # Inisialisasi df sebagai DataFrame kosong
    try:
        connection = pymysql.connect(**db_config)
        # --- 2. Ambil Semua Data Produk dari Database ---
        query = "SELECT id, name, tags FROM products"
        df = pd.read_sql(query, connection)

    except Exception as e:
        # Jika koneksi gagal, kirim pesan error
        print(json.dumps({"error": f"Database connection failed: {e}"}))
        return
    finally:
        if 'connection' in locals() and connection.open:
            connection.close()

    # Cek jika DataFrame kosong setelah query
    if df.empty:
        print(json.dumps({"error": "No data returned from the database."}))
        return
        
    # --- 3. Pra-pemrosesan Data ---
    # Ganti nilai 'tags' yang kosong (None/NaN) dengan string kosong
    df['tags'] = df['tags'].fillna('')

    # --- 4. Kalkulasi TF-IDF ---
    # Inisialisasi TfidfVectorizer. Stop words bisa ditambahkan jika perlu.
    tfidf = TfidfVectorizer()
    # Buat matriks TF-IDF dari kolom 'tags'
    tfidf_matrix = tfidf.fit_transform(df['tags'])

    # --- 5. Kalkulasi Cosine Similarity ---
    # Buat matriks kemiripan antar semua produk
    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

    # --- 6. Dapatkan Rekomendasi ---
    try:
        # Dapatkan indeks dari produk yang sedang dilihat berdasarkan ID
        idx = df.index[df['id'] == product_id].tolist()[0]
    except IndexError:
        # Jika ID produk tidak ditemukan di dalam DataFrame
        print(json.dumps({"error": "Product ID not found in DataFrame."}))
        return

    # Dapatkan skor kemiripan produk tersebut dengan semua produk lain
    sim_scores = list(enumerate(cosine_sim[idx]))
    
    # Urutkan produk berdasarkan skor kemiripan (dari tertinggi ke terendah)
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    
    # Ambil N produk teratas, lewati produk itu sendiri (indeks pertama setelah diurutkan)
    sim_scores = sim_scores[1:num_recommendations+1]
    
    # Dapatkan indeks dari produk yang direkomendasikan
    product_indices = [i[0] for i in sim_scores]

    # Ambil ID produk yang asli dari DataFrame berdasarkan indeks
    recommended_product_ids = df['id'].iloc[product_indices].tolist()

    # --- 7. Kembalikan Hasil dalam Format JSON ---
    # Laravel akan lebih mudah membaca output JSON
    print(json.dumps(recommended_product_ids))


if __name__ == "__main__":
    # Script akan dijalankan dari sini
    if len(sys.argv) > 1:
        try:
            # Ambil ID produk dari argumen command line
            target_product_id = int(sys.argv[1])
            get_recommendations(target_product_id)
        except ValueError:
            print(json.dumps({"error": "Invalid Product ID provided."}))
    else:
        print(json.dumps({"error": "No Product ID provided."}))